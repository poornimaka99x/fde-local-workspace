import { spawn, spawnSync } from 'node:child_process'
import { chmodSync, cpSync, mkdirSync, writeFileSync } from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import type { SpawnTerminal, TerminalProcess } from '../../server/src/services/sessions'

/**
 * The end-to-end environment: a real `fde` controller over a throwaway FDE root,
 * seeded with the runs the flows need. Nothing here touches the operator's own
 * ~/.claude-shared, profiles, credentials or runs.
 */
export const E2E_TOKEN = 'e2e-token-not-a-real-one'

export interface Seeded {
  home: string
  shared: string
  runsRoot: string
  controller: string
  launcher: string
  repo: string
  projectId: string
  previousRunId: string
}

function repoRoot(): string {
  return path.resolve(path.dirname(new URL(import.meta.url).pathname), '..', '..', '..')
}

export function seed(root: string): Seeded {
  const home = path.join(root, 'home')
  const shared = path.join(home, '.claude-shared')
  const repo = path.join(root, 'returns-api')
  for (const dir of [
    path.join(shared, 'bin'),
    path.join(shared, 'config'),
    path.join(shared, 'mcp'),
    repo,
  ]) {
    mkdirSync(dir, { recursive: true })
  }
  // Every identity the seeded runs assign must look installed, or the
  // controller rightly refuses the assignment.
  for (const profile of ['work', 'msc', 'alt', 'bedrock']) {
    const dir = path.join(home, '.claude-profiles', profile)
    mkdirSync(dir, { recursive: true })
    writeFileSync(path.join(dir, '.credentials.json'), '{}')
  }
  writeFileSync(
    path.join(home, '.claude-profiles', 'bedrock', 'settings.json'),
    JSON.stringify({ env: { AWS_PROFILE: 'bedrock-dev', AWS_REGION: 'eu-west-1' } }),
  )
  const source = path.join(repoRoot(), 'claude-shared')
  cpSync(path.join(source, 'bin', 'fde'), path.join(shared, 'bin', 'fde'))
  cpSync(path.join(source, 'config', 'agents.json'), path.join(shared, 'config', 'agents.json'))
  cpSync(path.join(source, 'mcp', 'mcp-servers.json'), path.join(shared, 'mcp', 'mcp-servers.json'))
  chmodSync(path.join(shared, 'bin', 'fde'), 0o755)

  // A launcher that behaves like fde-start for the session flow: it greets,
  // echoes what is typed, and exits when told. No Claude, no network.
  const launcher = path.join(shared, 'bin', 'fde-start')
  writeFileSync(
    launcher,
    [
      '#!/bin/sh',
      'echo "FDE run $2 — orchestrator session"',
      'echo "Give the request, then type APPROVE PLAN $2"',
      'while IFS= read -r line; do',
      '  case "$line" in',
      '    /exit) echo "goodbye"; exit 0 ;;',
      '    *) echo "you said: $line" ;;',
      '  esac',
      'done',
    ].join('\n') + '\n',
  )
  chmodSync(launcher, 0o755)

  const controller = path.join(shared, 'bin', 'fde')
  const env = {
    ...process.env,
    HOME: home,
    CLAUDE_SHARED: shared,
    CLAUDE_PROFILES_DIR: path.join(home, '.claude-profiles'),
    FDE_RUNS_DIR: path.join(shared, 'runs'),
    FDE_PROJECTS_DIR: path.join(shared, 'projects'),
  }
  const fde = (...args: string[]): string => {
    const result = spawnSync('python3', [controller, ...args], { env, encoding: 'utf8' })
    if (result.status !== 0) {
      throw new Error(`fde ${args.join(' ')} failed: ${result.stderr || result.stdout}`)
    }
    return result.stdout
  }

  const project = JSON.parse(
    fde('project', 'create', '--name', 'Returns modernisation', '--description',
      'Store and web returns', '--repo', repo, '--json'),
  ) as { project: { projectId: string } }
  const projectId = project.project.projectId

  // A run that already has history: a confirmed plan, roles, an artifact and a
  // checkpoint — the "previous run" an operator opens to see what happened.
  const previous = JSON.parse(
    fde('start', '--json', '--orchestrator', 'work', '--project', projectId, '--',
      'MAX-142 research the returns journey and review it'),
  ) as { run: { runId: string } }
  const previousRunId = previous.run.runId
  fde('plan', previousRunId, '--stages', 'intake,research,review', '--intent',
    'research the returns journey, then have it reviewed')
  fde('roles', previousRunId, '--set', 'research=claude_work', '--set', 'review=claude_msc',
    '--set', 'productManagement=none', '--set', 'prReview=none', '--set',
    'standardsReview=none', '--set', 'securityReview=none', '--set', 'microsoftContext=none')
  const runDir = path.join(shared, 'runs', previousRunId)
  mkdirSync(path.join(runDir, 'artifacts', 'research'), { recursive: true })
  writeFileSync(
    path.join(runDir, 'artifacts', 'research', 'research-brief.md'),
    '# Research brief\n\nReturns take 11 days end to end.\n\n- store returns are keyed by till id\n- web returns arrive as a nightly file\n',
  )
  fde('checkpoint', previousRunId, '--stage', 'research', '--status', 'pass',
    '--evidence', 'artifacts/research/research-brief.md', '--note', 'brief reviewed with the PO')
  writeFileSync(path.join(runDir, 'orchestrator-session-id'), '0b9d6c2e-1f3a-4a5b-8c7d-9e0f1a2b3c4d\n')

  return { home, shared, runsRoot: path.join(shared, 'runs'), controller, launcher, repo, projectId, previousRunId }
}

/**
 * A terminal backed by pipes rather than a pty.
 *
 * node-pty is a native module that could not be built in this environment, so
 * the end-to-end flow drives the same session machinery through real OS
 * processes instead. It lives in test code and is never shipped: the server
 * refuses to start a session when it has no real backend.
 */
export const pipeTerminal: SpawnTerminal = (options): TerminalProcess => {
  const child = spawn(options.file, options.args, {
    cwd: options.cwd,
    env: options.env,
    stdio: ['pipe', 'pipe', 'pipe'],
  })
  const data: ((chunk: string) => void)[] = []
  const exits: ((event: { exitCode: number }) => void)[] = []
  child.stdout.setEncoding('utf8')
  child.stderr.setEncoding('utf8')
  child.stdout.on('data', (chunk: string) => data.forEach((listener) => listener(chunk)))
  child.stderr.on('data', (chunk: string) => data.forEach((listener) => listener(chunk)))
  child.on('close', (code, signal) =>
    exits.forEach((listener) => listener({ exitCode: code ?? (signal === null ? 0 : 130) })),
  )
  return {
    get pid() {
      return child.pid ?? -1
    },
    onData: (listener) => data.push(listener),
    onExit: (listener) => exits.push(listener),
    // A pty's line discipline turns the Enter key's carriage return into a
    // newline before the program sees it. Pipes have no line discipline, so the
    // stand-in does it here — otherwise a shell reading lines would wait
    // forever for input the operator has already sent.
    write: (payload) => child.stdin.write(payload.replace(/\r/g, '\n')),
    resize: () => undefined,
    kill: (signal) => child.kill((signal ?? 'SIGTERM') as NodeJS.Signals),
  }
}

export function tempRoot(): string {
  return path.join(os.tmpdir(), `fde-e2e-${process.pid}`)
}
