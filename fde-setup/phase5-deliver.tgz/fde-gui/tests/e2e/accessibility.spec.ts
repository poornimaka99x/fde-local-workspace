import AxeBuilder from '@axe-core/playwright'
import { expect, test, type Page } from '@playwright/test'
import { E2E_TOKEN } from './harness'

/**
 * An accessibility audit of every screen, run against the real console.
 *
 * The rules checked are the WCAG 2.1 A and AA sets, including colour contrast —
 * which needs a real browser, and is why this lives here rather than in jsdom.
 */
async function open(page: Page, path: string): Promise<void> {
  await page.goto(`${path}#token=${E2E_TOKEN}`)
  await expect(page.getByRole('navigation', { name: 'Sections' })).toBeVisible()
}

async function audit(page: Page): Promise<void> {
  const results = await new AxeBuilder({ page })
    .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
    .analyze()
  expect(
    results.violations.map((violation) => ({
      id: violation.id,
      impact: violation.impact,
      nodes: violation.nodes.map((node) => node.target.join(' ')),
    })),
  ).toEqual([])
}

test.describe('accessibility', () => {
  for (const [name, path] of [
    ['projects', '/projects'],
    ['runs', '/runs'],
    ['new run', '/runs/new'],
    ['new project', '/projects/new'],
    ['active sessions', '/sessions'],
    ['system health', '/health'],
  ] as const) {
    test(`${name} has no WCAG A/AA violations`, async ({ page }) => {
      await open(page, path)
      await page.waitForTimeout(300)
      await audit(page)
    })
  }

  test('a run detail page has none either, on every tab', async ({ page }) => {
    await open(page, '/runs')
    await page.getByRole('link', { name: /max-142/ }).click()
    for (const tab of ['Overview', 'Session', 'Inputs', 'Artifacts', 'Events', 'Approvals & evidence']) {
      await page.getByRole('tab', { name: new RegExp(tab) }).click()
      await page.waitForTimeout(200)
      await audit(page)
    }
  })

  test('the light theme meets contrast too', async ({ browser }) => {
    const context = await browser.newContext({ colorScheme: 'light' })
    const page = await context.newPage()
    await open(page, '/runs')
    await page.waitForTimeout(300)
    await audit(page)
    await context.close()
  })

  test('every screen can be reached and driven from the keyboard', async ({ page }) => {
    await open(page, '/runs')
    // Tab once: the skip link, which is how a keyboard user gets past the nav.
    await page.keyboard.press('Tab')
    await expect(page.getByRole('link', { name: 'Skip to content' })).toBeFocused()

    await page.getByRole('link', { name: /max-142/ }).click()
    const overview = page.getByRole('tab', { name: 'Overview' })
    await overview.focus()
    await page.keyboard.press('ArrowRight')
    await expect(page.getByRole('tab', { name: 'Session' })).toBeFocused()
    await expect(page.getByRole('tab', { name: 'Session' })).toHaveAttribute('aria-selected', 'true')
    await page.keyboard.press('End')
    await expect(page.getByRole('tab', { name: /Approvals/ })).toHaveAttribute('aria-selected', 'true')
  })
})
