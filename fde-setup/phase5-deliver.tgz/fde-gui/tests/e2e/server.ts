import { mkdirSync, writeFileSync } from 'node:fs'
import path from 'node:path'
import { buildApp } from '../../server/src/app'
import { loadConfig } from '../../server/src/config'
import { SessionManager } from '../../server/src/services/sessions'
import { E2E_TOKEN, pipeTerminal, seed, tempRoot } from './harness'

/**
 * The console, started for the end-to-end flows against a seeded throwaway FDE
 * root. Same server the operator runs; only the terminal backend and the roots
 * differ.
 */
async function main(): Promise<void> {
  const root = tempRoot()
  mkdirSync(root, { recursive: true })
  const seeded = seed(root)
  writeFileSync(path.join(root, 'seeded.json'), JSON.stringify(seeded, null, 2))

  const config = loadConfig({
    ...process.env,
    HOME: seeded.home,
    CLAUDE_SHARED: seeded.shared,
    CLAUDE_PROFILES_DIR: path.join(seeded.home, '.claude-profiles'),
    FDE_RUNS_DIR: seeded.runsRoot,
    FDE_PROJECTS_DIR: path.join(seeded.shared, 'projects'),
    FDE_CONTROLLER: seeded.controller,
    FDE_START_BIN: seeded.launcher,
    FDE_GUI_TOKEN: E2E_TOKEN,
    FDE_GUI_PORT: process.env.E2E_PORT ?? '7391',
  } as NodeJS.ProcessEnv)

  const app = buildApp(config, { sessions: new SessionManager(pipeTerminal) })
  await app.listen({ host: config.host, port: config.port })
  process.stdout.write(`e2e console on http://${config.host}:${config.port} root=${root}\n`)
}

void main()
