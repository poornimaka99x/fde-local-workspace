import { expect, test, type Page } from '@playwright/test'
import { E2E_TOKEN } from './harness'

/**
 * The operator guide's screenshots, captured from the running console against
 * the seeded throwaway root. Run with `npm run screenshots`; the images land in
 * `docs/screenshots/`.
 */
const OUT = '../docs/screenshots'

async function open(page: Page, path: string): Promise<void> {
  await page.goto(`${path}#token=${E2E_TOKEN}`)
  await expect(page.getByRole('navigation', { name: 'Sections' })).toBeVisible()
}

test.describe('screenshots', () => {
  test('capture the console', async ({ page }) => {
    await open(page, '/projects')
    await expect(page.getByRole('heading', { name: 'Returns modernisation' })).toBeVisible()
    await page.screenshot({ path: `${OUT}/projects.png` })

    await page.getByRole('link', { name: 'All runs' }).click()
    await expect(page.getByRole('link', { name: /max-142/ })).toBeVisible()
    await page.screenshot({ path: `${OUT}/runs.png` })

    await page.getByRole('link', { name: /max-142/ }).click()
    await expect(page.getByRole('tab', { name: 'Overview' })).toBeVisible()
    await page.screenshot({ path: `${OUT}/run-overview.png` })

    await page.getByRole('tab', { name: /Events/ }).click()
    await page.screenshot({ path: `${OUT}/run-events.png` })

    await page.getByRole('tab', { name: /Approvals/ }).click()
    await page.screenshot({ path: `${OUT}/run-evidence.png` })

    await page.getByRole('tab', { name: /Artifacts/ }).click()
    await page.getByRole('button', { name: /research-brief\.md/ }).click()
    await expect(page.getByRole('heading', { name: 'Research brief' })).toBeVisible()
    await page.screenshot({ path: `${OUT}/run-artifacts.png` })

    await page.getByRole('tab', { name: 'Session' }).click()
    await page.getByRole('button', { name: /Resume session|Start again/ }).click()
    const terminal = page.getByRole('group', { name: 'Orchestrator session terminal' })
    await expect(terminal).toContainText('orchestrator session', { timeout: 15_000 })
    await terminal.click()
    await page.keyboard.type('research the returns journey')
    await page.keyboard.press('Enter')
    await expect(terminal).toContainText('you said:', { timeout: 15_000 })
    await page.screenshot({ path: `${OUT}/run-session.png` })

    await page.getByRole('link', { name: 'Active sessions' }).click()
    await expect(page.getByRole('heading', { name: 'Active sessions' })).toBeVisible()
    await page.screenshot({ path: `${OUT}/sessions.png` })

    await page.getByRole('link', { name: 'System health' }).click()
    await expect(page.getByRole('heading', { name: 'System health' })).toBeVisible()
    await page.screenshot({ path: `${OUT}/health.png` })

    await page.getByRole('link', { name: 'All runs' }).click()
    await page.getByRole('link', { name: 'New run' }).click()
    await expect(page.getByRole('heading', { name: 'New run' })).toBeVisible()
    await page.screenshot({ path: `${OUT}/new-run.png` })
  })

  test('capture the light theme', async ({ browser }) => {
    const context = await browser.newContext({ colorScheme: 'light', viewport: { width: 1440, height: 900 } })
    const page = await context.newPage()
    await open(page, '/runs')
    await expect(page.getByRole('link', { name: /max-142/ })).toBeVisible()
    await page.screenshot({ path: `${OUT}/runs-light.png` })
    await page.getByRole('link', { name: /max-142/ }).click()
    await expect(page.getByRole('tab', { name: 'Overview' })).toBeVisible()
    await page.screenshot({ path: `${OUT}/run-overview-light.png` })
    await context.close()
  })

  test('capture a narrow window', async ({ browser }) => {
    const context = await browser.newContext({ viewport: { width: 720, height: 900 } })
    const page = await context.newPage()
    await open(page, '/runs')
    await expect(page.getByRole('link', { name: /max-142/ })).toBeVisible()
    await page.screenshot({ path: `${OUT}/runs-narrow.png`, fullPage: true })
    await context.close()
  })
})
