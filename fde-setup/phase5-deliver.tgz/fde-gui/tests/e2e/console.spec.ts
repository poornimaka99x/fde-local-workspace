import { expect, test, type Page } from '@playwright/test'
import { E2E_TOKEN } from './harness'

/** The console hands its token over in the fragment, exactly as the launcher does. */
async function open(page: Page, path = '/runs'): Promise<void> {
  await page.goto(`${path}#token=${E2E_TOKEN}`)
  await expect(page.getByRole('navigation', { name: 'Sections' })).toBeVisible()
}

test.describe('the flows an operator actually walks', () => {
  test('1. create a project, create a run, and see it grouped under the project', async ({ page }) => {
    await open(page, '/projects')
    await page.getByRole('link', { name: 'New project' }).click()
    await page.getByLabel('Name').fill('Checkout resilience')
    await page.getByLabel('Description').fill('Make checkout survive a payment outage')
    await page.getByRole('button', { name: 'Create project' }).click()

    await expect(page.getByRole('heading', { name: 'Checkout resilience' })).toBeVisible()
    await page.getByRole('link', { name: 'New run' }).click()
    await page.getByLabel('What do you want done?').fill('MAX-500 survive a payment outage')
    await page.getByLabel('Orchestrator').selectOption('work')
    await page.getByRole('button', { name: 'Create run' }).click()

    await expect(page.getByText('MAX-500 survive a payment outage')).toBeVisible()
    await expect(page.getByText('awaiting_plan', { exact: true }).first()).toBeVisible()

    await page.getByRole('link', { name: 'Projects' }).click()
    const card = page.locator('.card', { hasText: 'Checkout resilience' })
    await expect(card.getByText('1 run(s)')).toBeVisible()
  })

  test('2. attach a file and see its name, size and digest', async ({ page }) => {
    await open(page, '/runs')
    await page.getByRole('link', { name: /^2026/ }).first().click()
    await page.getByRole('tab', { name: /Inputs/ }).click()

    await page.getByLabel('File to attach').setInputFiles({
      name: 'requirements.pdf',
      mimeType: 'application/pdf',
      buffer: Buffer.from('a requirement document'),
    })
    await page.getByRole('button', { name: 'Attach', exact: true }).click()

    await expect(page.getByRole('status')).toContainText('requirements.pdf')
    const row = page.getByRole('row', { name: /requirements\.pdf/ })
    await expect(row).toContainText('22 B')
    // The digest of exactly those bytes, as the controller recorded it.
    await expect(row).toContainText('799e2319b2a8')
  })

  test('3. open a previous run and inspect its plan, roles and events', async ({ page }) => {
    await open(page, '/runs')
    await page.getByRole('link', { name: /max-142/ }).click()

    await expect(page.getByRole('paragraph').filter({ hasText: 'MAX-142 research' })).toBeVisible()
    await expect(page.getByText('adversarial review', { exact: true })).toBeVisible()
    await expect(page.getByRole('row', { name: /Researcher/ })).toContainText('Claude: work')
    await expect(page.getByRole('row', { name: /Reviewer/ })).toContainText('Claude: msc')

    await page.getByRole('tab', { name: /Events/ }).click()
    await expect(page.getByText('roles.confirmed').first()).toBeVisible()
    await expect(page.getByText('checkpoint.recorded').first()).toBeVisible()

    await page.getByRole('tab', { name: /Approvals/ }).click()
    await expect(page.getByText('Nothing has been approved on this run.')).toBeVisible()
    await expect(page.getByText('brief reviewed with the PO')).toBeVisible()
  })

  test('4. resume a stubbed Claude session in the embedded terminal', async ({ page }) => {
    await open(page, '/runs')
    await page.getByRole('link', { name: /max-142/ }).click()
    await page.getByRole('tab', { name: 'Session' }).click()

    await page.getByRole('button', { name: 'Resume session' }).click()
    const terminal = page.getByRole('group', { name: 'Orchestrator session terminal' })
    await expect(terminal).toContainText('orchestrator session', { timeout: 15_000 })
    await expect(page.getByText('attached')).toBeVisible()

    await terminal.click()
    await page.keyboard.type('APPROVE PLAN')
    await page.keyboard.press('Enter')
    await expect(terminal).toContainText('you said: APPROVE PLAN', { timeout: 15_000 })

    await page.getByRole('link', { name: 'Active sessions' }).click()
    await expect(page.getByRole('row', { name: /max-142/ })).toContainText('running')

    await page.getByRole('link', { name: /max-142/ }).click()
    await page.getByRole('tab', { name: 'Session' }).click()
    await page.getByRole('button', { name: 'Stop' }).click()
    await expect(page.getByText(/Interrupt sent/)).toBeVisible()
  })

  test('5. a traversal download is refused', async ({ page, request }) => {
    await open(page, '/runs')
    const runId = (await page.getByRole('link', { name: /max-142/ }).innerText()).trim()

    for (const attempt of ['../../etc/passwd', '/etc/passwd', 'approvals.jsonl', 'mcp/claude-work.mcp.json']) {
      const response = await request.get(
        `/api/runs/${runId}/files/content?path=${encodeURIComponent(attempt)}`,
        { headers: { authorization: `Bearer ${E2E_TOKEN}` } },
      )
      expect(response.status(), attempt).toBeGreaterThanOrEqual(400)
      expect(await response.text()).not.toContain('root:')
    }

    const allowed = await request.get(
      `/api/runs/${runId}/files/content?path=${encodeURIComponent('artifacts/research/research-brief.md')}`,
      { headers: { authorization: `Bearer ${E2E_TOKEN}` } },
    )
    expect(allowed.status()).toBe(200)
    expect(await allowed.text()).toContain('Returns take 11 days')
  })

  test('6. a controller refusal is shown, and changes nothing', async ({ page, request }) => {
    await open(page, '/projects')
    const before = await (
      await request.get('/api/projects', { headers: { authorization: `Bearer ${E2E_TOKEN}` } })
    ).json()

    await page.getByRole('link', { name: 'New project' }).click()
    await page.getByLabel('Name').fill('Refused on purpose')
    await page.getByLabel('Repositories').fill('/definitely/not/a/repository')
    await page.getByRole('button', { name: 'Create project' }).click()

    const alert = page.getByRole('alert')
    await expect(alert).toContainText('repository path does not exist')
    await expect(page.getByRole('heading', { name: 'New project' })).toBeVisible()

    const after = await (
      await request.get('/api/projects', { headers: { authorization: `Bearer ${E2E_TOKEN}` } })
    ).json()
    expect(after.projects).toHaveLength(before.projects.length)
    expect(JSON.stringify(after)).not.toContain('Refused on purpose')
  })
})
