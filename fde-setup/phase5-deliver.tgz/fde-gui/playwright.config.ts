import { defineConfig } from '@playwright/test'

const PORT = process.env.E2E_PORT ?? '7391'

/**
 * The end-to-end flows run against the real server and the real `fde`
 * controller over a throwaway FDE root. One worker: the flows share that root
 * on purpose, because a console is a single-operator tool.
 */
export default defineConfig({
  testDir: './tests/e2e',
  testMatch: '**/*.spec.ts',
  fullyParallel: false,
  workers: 1,
  retries: 0,
  timeout: 30_000,
  reporter: process.env.CI === 'true' ? 'line' : [['list']],
  use: {
    baseURL: `http://127.0.0.1:${PORT}`,
    // Where a machine already has a Chromium (a CI image, a sandbox), use it
    // rather than downloading another copy. Unset locally: Playwright then uses
    // the browser it installed itself.
    ...(process.env.PLAYWRIGHT_CHROMIUM_PATH
      ? { launchOptions: { executablePath: process.env.PLAYWRIGHT_CHROMIUM_PATH } }
      : {}),
    viewport: { width: 1440, height: 900 },
    colorScheme: 'dark',
    trace: 'retain-on-failure',
  },
  webServer: {
    command: 'npm run build && npx tsx tests/e2e/server.ts',
    url: `http://127.0.0.1:${PORT}/`,
    reuseExistingServer: false,
    timeout: 120_000,
    env: { E2E_PORT: PORT },
  },
})
