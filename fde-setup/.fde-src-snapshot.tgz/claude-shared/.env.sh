export CONFLUENCE_BASE_URL="https://maxedadiy.atlassian.net"
export CONFLUENCE_EMAIL="Poornima.Kahatapitiya@diymaxeda.com"
export CONFLUENCE_API_TOKEN="ATATT3xFfGF0SF43VQXT_aVqEQWQH5rpsyuQK34g1EwhjA1DBBGiW7E-8AeKk0odTEMixiHasR9dR03hpgwnYrEvlbUEAO6XUYZPehThhexPWNlkqCxivCrLoTLhIYAkrLbbibr1F2b0Rm8NFw4aAw8E3WK0pr2d12_5TssNJCCbCc-LLiidgoQ=DC175FA6"

# --- Microsoft option 2: Copilot Studio agent over Direct Line ---------------
# Set ONE of these. Copilot Studio > your agent > Channels.
export COPILOT_DIRECTLINE_SECRET=""
# export COPILOT_TOKEN_ENDPOINT=""

# --- AWS profile used by the Bedrock Claude profile --------------------------
export MAXEDA_AWS_PROFILE="bedrock-dev"
export MAXEDA_AWS_REGION="eu-west-1"